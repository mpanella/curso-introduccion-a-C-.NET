﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operadores.Cs
{
    class Program
    {
        public static void Ejercicio_1()
        {
            Console.WriteLine("Ejercicio 1 - Asignación básica");
            Console.WriteLine("");

            Console.WriteLine("A");
            int x = 10;
            int y=20;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("B");
            x = x + 5;
            y = y + 10;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("C");
            x = x - 5;
            y = y - 10;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("D");
            x = x * 3;
            y = y * 5;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("E");
            x = x / 2;
            y = y / 4;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }

        public static void Ejercicio_2()
        {
            Console.WriteLine("Ejercicio 2 - Asignación compacta");
            Console.WriteLine("");
            Console.WriteLine("A");
            int x = 10;
            int y=20;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("B");
             x += 5;
             y -= 15;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("C");
            x++;
            y--;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("D");
            x *=4;
            y *=-3;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("E");
            x /=2;
            y /=4;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();


        }

        public static void Ejercicio_3()
        {
            Console.WriteLine("Ejercicio 3 - Operadores aritméticos");
            Console.WriteLine("");
            Console.WriteLine("A");
            int x = 10;
            int y=20;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("B");
             x =x+y;
             y =y+x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("C");
            x=x-y;
            y=y-x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("D");
            x=x*y;
            y=x*x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("E");
            x=y/x;
            y=x/y;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Ejercicio_4()
        {
            Console.WriteLine("Ejercicio 4 - Operadores aritméticos con asignación compacta");
            Console.WriteLine("");

            Console.WriteLine("A");
            int x = 5;
            int y=10;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("B");
             x +=y;
             y +=x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("C");
            x-=y;
            y-=x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("D");
            x*=y;
            y*=x;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("E");
            x/=y ;
            y/=y ;
            Console.WriteLine(x);
            Console.WriteLine(y);
            
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Ejercicio_5()
        {
            Console.WriteLine("Ejercicio 5 - Operadores Aritméticos con asignación múltiple (suma y resta)");
            Console.WriteLine("");

            Console.WriteLine("A");
            int x = 5;
            int y=10;
            int suma=0;
            int resta=0;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(suma);
            Console.WriteLine(resta);

            Console.WriteLine("B");
             suma=x+y;
             resta=x-y;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("C");
             suma=x+x;
             resta=y-y;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("D");
             suma=x+y+x;
             resta=x-x-20;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("E");
             suma=y+x+x;
             resta=-x-y-y;
            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }
     
        public static void Ejercicio_6()
        {
            Console.WriteLine("Ejercicio 6 - Operadores Aritméticos con asignación múltiple (producto y división)");
            Console.WriteLine("");

            Console.WriteLine("A");
            int x = 5;
            int y=10;
            int multi=1;
            int division=1;
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(multi);
            Console.WriteLine(division);

            Console.WriteLine("B");
            multi=x*y;
            division=x/y;
            Console.WriteLine(multi);
            Console.WriteLine(division);

            Console.WriteLine("C");
            multi=x*x;
            division=y/y;
            Console.WriteLine(multi);
            Console.WriteLine(division);

            Console.WriteLine("D");
            multi=x*y*x;
            division=y/x;
            Console.WriteLine(multi);
            Console.WriteLine(division);

            Console.WriteLine("E");
            multi=x*(-y);
            division=y/(-x);
            Console.WriteLine(multi);
            Console.WriteLine(division);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }

        public static void Ejercicio_7()
        {
            Console.WriteLine("Ejercicio 7 - Operador Resto)");
            Console.WriteLine("");

            Console.WriteLine("A");
            int n1=15;
            int n2=2;
            int n3=n1%n2;
            Console.WriteLine(n3);

            Console.WriteLine("C");
            n1=3;
            n2=20;
            n3=n2%n1;
            Console.WriteLine(n3);

            Console.WriteLine("D");
            n1=3;
            n2=15;
            n3=n2%n1;
            Console.WriteLine(n3);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }


        public static void Ejercicio_8()
        {
            Console.WriteLine("Ejercicio 8 - Cadenas de Caracteres");
            Console.WriteLine("");
            Console.WriteLine("A");
            String palabra_1 ="Hola";
            String palabra_2 ="Mundo";
            String frase ="";
            Console.WriteLine(palabra_1);
            Console.WriteLine(palabra_2);
            Console.WriteLine(frase);

            Console.WriteLine("B");
            frase =palabra_1+palabra_2;
            Console.WriteLine(palabra_1);
            Console.WriteLine(palabra_2);
            Console.WriteLine(frase);

            Console.WriteLine("C");
            frase =palabra_1 + " \t "+ palabra_2;
            Console.WriteLine(palabra_1);
            Console.WriteLine(palabra_2);
            Console.WriteLine(frase);

            Console.WriteLine("D");
            frase =palabra_1+" \n " + palabra_2;
            Console.WriteLine(palabra_1);
            Console.WriteLine(palabra_2);
            Console.WriteLine(frase);

            Console.WriteLine("E");
            frase =palabra_1+" \n \t "+palabra_2;
            Console.WriteLine(palabra_1);
            Console.WriteLine(palabra_2);
            Console.WriteLine(frase);


            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Ejercicio_9()
        {
            Console.WriteLine("Ejercicio 9 - Operadores Lógicos");
            Console.WriteLine("");
            Console.WriteLine("A");
            bool n1=true;
            bool n2=false;
            bool n3=!n1;
            bool n4=!n2;
            Console.WriteLine(n3);
            Console.WriteLine(n4);

            Console.WriteLine("B");
            n3=n1 & n2;
            n4=n1 | n2;
            Console.WriteLine(n3);
            Console.WriteLine(n4);

            Console.WriteLine("C");
            n3=!(n1 & n2);
            n4=!(n1 | n2);
            Console.WriteLine(n3);
            Console.WriteLine(n4);

            Console.WriteLine("D");
            n3=!n1 & n2;
            n4=!n1 | n2;
            Console.WriteLine(n3);
            Console.WriteLine(n4);

            Console.WriteLine("E");
            n3=n1^ n2;
            n4=n1^ !n2;
            Console.WriteLine(n3);
            Console.WriteLine(n4);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }


        public static void Bonus_1()
        {
            Console.WriteLine("Bonus 1");
            Console.WriteLine("");

            int n1 = 5, n2 = 10, n3 = 20;
            Console.WriteLine("n1+n2= " + (n1 + n2));
            Console.WriteLine("n3-n1= " + (n3 - n1));
            Console.WriteLine("n1*n3= " + n1 * n3);
            Console.WriteLine("n3/n2= " + n3 / n2);


            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Bonus_2()
        {
            Console.WriteLine("Bonus 2");
            Console.WriteLine("");

            int n1 = 10, n2 = 10, n3 = 20;
            int total = n1 + n2 + n3;
            double promedio = total / 3;
            int resto = n2 % n1;

            Console.WriteLine("total= " + total);
            Console.WriteLine("promedio= " + promedio);
            Console.WriteLine("resto= " + resto);

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Bonus_3()
        {
            Console.WriteLine("Bonus 3");
            Console.WriteLine("");

            bool n1 = true, n2 = false, n3 = true;
            Console.WriteLine(" n1 ^ n2= " + (n1 ^ n2));
            Console.WriteLine("(n1 & !n2) | n3= " + ((n1 & !n2) | n3));
            Console.WriteLine("(n1 | n2) & !n3= " + ((n1 | n2) & !n3));


            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }

        public static void Bonus_4()
        {
            Console.WriteLine("Bonus 4");
            Console.WriteLine("");

            int n1 = 5, n2 = 10;
            Console.WriteLine("n1 es igual a " + n1 + ", n2 es igual a " + n2 + " y n1 mas n2 es igual a " + (n1 + n2));


            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }

        public static void Bonus_5()
        {
            Console.WriteLine("Bonus 5 - Uso de constantes");
            Console.WriteLine("");

            double remera = 59.9, pantalon = 99.9, campera = 149.9;
            const double IVA = 21;

            Console.WriteLine("precio final remera: " + (remera + remera * IVA / 100));
            Console.WriteLine("precio final pantalon: " + (pantalon + pantalon * IVA / 100));
            Console.WriteLine("precio final remera: " + (campera + campera * IVA / 100));

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();

        }


        static void Main(string[] args)
        {

           Bonus_5();

        }
    }
}
