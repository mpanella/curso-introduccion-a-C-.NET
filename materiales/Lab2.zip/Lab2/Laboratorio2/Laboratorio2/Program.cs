﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio2
{
    class Program
    {

        public static void Ejercicio_4()
        {
            int n1, n2, opcion;

            Console.WriteLine("Ingrese el primer número: ");
            n1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo número: ");
            n2 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese su opcion: ");
            Console.WriteLine("1 Suma");
            Console.WriteLine("2 Resta");
            Console.WriteLine("3 Multiplicación");
            Console.WriteLine("4 Division");
            Console.WriteLine("");
            Console.WriteLine("Opción: ");
            opcion = Int32.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine("Suma: " + (n1 + n2));
                    break;
                case 2:
                    Console.WriteLine("Resta: " + (n1 - n2));
                    break;
                case 3:
                    Console.WriteLine("Multiplicacion: " + (n1 * n2));
                    break;
                case 4:
                    Console.WriteLine("División: " + (n1 / n2));
                    break;

            }
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadLine();
        }

        public static void Bonus_1()
        {
            Console.WriteLine("A");
            int n1=20;
            int n2=10;
            int n3=(n1>n2)? n1:0;
            Console.WriteLine(n3);

            Console.WriteLine("B");
            n1=20;
            n2=10;
            n3=(n1<n2)? n1:0;
            Console.WriteLine(n3);

            Console.WriteLine("C");
            n1=20;
            n2=10;
            n3=(n1==n2)? n1:0;
            Console.WriteLine(n3);

            Console.WriteLine("D");
            n1=20;
            n2=10;
            n3=(n1!=n2)? n1:0;
            Console.WriteLine(n3);

            Console.ReadLine();



        }
        static void Main(string[] args)
        {
            Bonus_1();

            
        }
    }
}
